package com.example.bookstore1.service;

public interface TimerService {
    void Start();
    long End();
}
